# -*- coding: utf-8 -*-
def classFactory(iface):  # pylint: disable=invalid-name
    from .graduatedsymbol_sample import GraduatedSymbolSample
    return GraduatedSymbolSample(iface)
